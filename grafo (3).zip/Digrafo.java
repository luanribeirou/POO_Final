public abstract class Digrafo implements Digraph<T,E>{

  public Digraph DijkstraAlgorithm(int s) {

	// Atributos usados na funcao encontrarMenorCaminho

	// Lista que guarda os vertices pertencentes ao menor caminho encontrado
	List<Vertice> menorCaminho = new ArrayList<Vertice>();

	// Variavel que recebe os vertices pertencentes ao menor caminho
	Vertice verticeCaminho = new Vertice();

	// Variavel que guarda o vertice que esta sendo visitado
	Vertice atual = new Vertice();

	// Variavel que marca o vizinho do vertice atualmente visitado
	Vertice vizinho = new Vertice();

	// Lista dos vertices que ainda nao foram visitados
	List<Vertice> naoVisitados = new ArrayList<Vertice>();

	// Algoritmo de Dijkstra
	public List<Vertice> encontrarMenorCaminhoDijkstra(Grafo grafo, Vertice v1,
			Vertice v2) {

		// Adiciona a origem na lista do menor caminho
		menorCaminho.add(v1);

		// Colocando a distancias iniciais
		for (int i = 0; i < grafo.getVertices().size(); i++) {

			// Vertice atual tem distancia zero, e todos os outros,
			// 9999("infinita")
			if (grafo.getVertices().get(i).getDescricao()
					.equals(v1.getDescricao())) {

				grafo.getVertices().get(i).setDistancia(0);

			} else {

				grafo.getVertices().get(i).setDistancia(9999);

			}
			// Insere o vertice na lista de vertices nao visitados
			this.naoVisitados.add(grafo.getVertices().get(i));
		}

		Collections.sort(naoVisitados);

		// O algoritmo continua ate que todos os vertices sejam visitados
		while (!this.naoVisitados.isEmpty()) {

			// Toma-se sempre o vertice com menor distancia, que eh o primeiro
			// da
			// lista

			atual = this.naoVisitados.get(0);
			System.out.println("Pegou esse vertice:  " + atual);
			/*
			 * Para cada vizinho (cada aresta), calcula-se a sua possivel
			 * distancia, somando a distancia do vertice atual com a da aresta
			 * correspondente. Se essa distancia for menor que a distancia do
			 * vizinho, esta eh atualizada.
			 */
			for (int i = 0; i < atual.getArestas().size(); i++) {

				vizinho = atual.getArestas().get(i).getDestino();
				System.out.println("Olhando o vizinho de " + atual + ": "
						+ vizinho);
				if (!vizinho.verificarVisita()) {

					// Comparando a distância do vizinho com a possível
					// distância
					if (vizinho.getDistancia() > (atual.getDistancia() + atual
							.getArestas().get(i).getPeso())) {

						vizinho.setDistancia(atual.getDistancia()
								+ atual.getArestas().get(i).getPeso());
						vizinho.setPai(atual);

						/*
						 * Se o vizinho eh o vertice procurado, e foi feita uma
						 * mudanca na distancia, a lista com o menor caminho
						 * anterior eh apagada, pois existe um caminho menor
						 * vertices pais, ateh o vertice origem.
						 */
						if (vizinho == v2) {
							menorCaminho.clear();
							verticeCaminho = vizinho;
							menorCaminho.add(vizinho);
							while (verticeCaminho.getPai() != null) {

								menorCaminho.add(verticeCaminho.getPai());
								verticeCaminho = verticeCaminho.getPai();

							}
							// Ordena a lista do menor caminho, para que ele
							// seja exibido da origem ao destino.
							Collections.sort(menorCaminho);

						}
					}
				}

			}
			// Marca o vertice atual como visitado e o retira da lista de nao
			// visitados
			atual.visitar();
			this.naoVisitados.remove(atual);
			/*
			 * Ordena a lista, para que o vertice com menor distancia fique na
			 * primeira posicao
			 */

			Collections.sort(naoVisitados);
			System.out.println("Nao foram visitados ainda:"+naoVisitados);

		}

		return menorCaminho;
	}

}
  public Digraph Floyd (){

	private static final int INFINITO = -1;
	private GrafoDP grafo;
	private int cantNodos;
	
	private int[][] custosMinimos;

	public GrafoDP getGrafo() {
		return grafo;
	}

	public int getCantNodos() {
		return cantNodos;
	}

	public int[][] getCustosMinimos() {
		return custosMinimos;
	}

	public Floyd(GrafoDP grafo) {
		this.grafo = grafo;
		this.cantNodos = grafo.getCantNodos();
		this.custosMinimos = new int[this.cantNodos][this.cantNodos];	
	}
	
	public void executar() throws IOException {
		// clono a matriz de adjacencia para calcular os custos mínimos
		this.custosMinimos = this.grafo.getGrafo().clone();
		
		int anterior, ik, kj, atual, minimo;
		
		// para cada iteração k del algoritmo
		for (int k = 0; k < this.cantNodos; k++) {
			// para cada fila de la matriz
			for (int i = 0; i < this.cantNodos; i++) {
				// para cada coluna da matriz
				for (int j = 0; j < this.cantNodos; j++) {
					
					// si o valor ij não está na diagonal principal nem na fila k o coluna k
					if (i != j && k != i && k != j) {
						// custo da iteração anterior
						anterior = this.custosMinimos[i][j];
						
						// custo de usar como intermediario o nodo k
						ik = this.custosMinimos[i][k];
						kj = this.custosMinimos[k][j];
						if (ik == INFINITO || kj == INFINITO) {
							atual = INFINITO;
						} else {
							atual = ik + kj;
						}
						
						// seleciono o custo mínimo
						if (atual != INFINITO && (atual < anterior || anterior == INFINITO)) {
							minimo = atual;
						} else {
							minimo = anterior;
						}
						this.custosMinimos[i][j] = minimo;
					}
				}
			}
		}
		
		// mostro solução no console
		this.escreverSoluçãoemConsole();
				
		// escrevo a solução completa em um arquivo
		this.escreverSoluçãoEmArquivo("FLOYD" + "_" + this.cantNodos + "_"
						+ String.format("%.2f", this.getGrafo().getPtajeAdjacencia()) + ".out");
			
	}

	private void escreverSoluçãoemConsole() {
		int custo;
		System.out.println("FLOYD: Custos mínimos entre todos os nodos ");
		for (int i = 0; i < this.cantNodos; i++) {
			for (int j = 0; j < this.cantNodos; j++) {
				custo = this.custosMinimos[i][j];
				if (custo == INFINITO) {
					System.out.println("Nodo Inicial: " + i + " Nodo Final: " + j + " Custo do Caminho Mais Curto: INFINITO");
				} else {
					System.out.println("Nodo Inicial: " + i + " Nodo Final: " + j + " Custo do Caminho Mais Curto: " + custo);
				}
			}
		}	
	}
	
	private void escreverSoluçãoEmArquivo(String path) throws IOException {
		FileWriter file = new FileWriter(path);
		BufferedWriter buffer = new BufferedWriter(file);
		
		buffer.write(String.valueOf(this.cantNodos));
		buffer.write(" ");
		buffer.write(String.valueOf(this.getGrafo().getCantAristas()));
		buffer.write(" ");
		buffer.write(String.valueOf(NumberFormat.getInstance().format(this.getGrafo().getPtajeAdjacencia())));
		buffer.write(" ");
		buffer.write(String.valueOf(this.getGrafo().getGradoMax()));
		buffer.write(" ");
		buffer.write(String.valueOf(this.getGrafo().getGradoMin()));
		buffer.newLine();
		
		for (int i = 0; i < this.cantNodos; i++) {
			for (int j = 0; j < this.cantNodos; j++) {
				buffer.write(String.valueOf(i));
				buffer.write(" ");
				buffer.write(String.valueOf(j));
				buffer.write(" ");
				buffer.write(String.valueOf(this.custosMinimos[i][j]));
				buffer.newLine();
			}
		}	
		
		buffer.close();
	}
	
}
}